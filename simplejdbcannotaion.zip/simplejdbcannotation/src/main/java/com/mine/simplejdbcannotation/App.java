package com.mine.simplejdbcannotation;

import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import com.mine.simplejdbcannotation.models.Employee;
import com.mine.simplejdbcannotation.repositories.EmployeeDaoInterface;
import com.mine.simplejdbcannotation.services.EmployeeDaoImpl;

/**
 * Hello world!
 *
 */
public class App 
{
    public static void main( String[] args )
    {
        System.out.println( "Hello World!" );
        ApplicationContext context=new AnnotationConfigApplicationContext(AppConfig.class);
        
        EmployeeDaoInterface employeeDaoImpl=context.getBean(EmployeeDaoImpl.class);
       // EmployeeDaoInterface
		//with EmployeeDaoImpl also works
		/*
		 * Employee employee=new Employee("kis", 80653); employeeDaoImpl.save(employee);
		 */
		 
       Employee employee1= employeeDaoImpl.findEmployee(804);
       
       System.out.println(employee1.getName()+"  "+employee1.getId());
    }
}
