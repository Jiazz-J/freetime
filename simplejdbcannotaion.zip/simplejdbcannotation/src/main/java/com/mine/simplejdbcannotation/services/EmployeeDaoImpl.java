package com.mine.simplejdbcannotation.services;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Service;

import com.mine.simplejdbcannotation.models.Employee;
import com.mine.simplejdbcannotation.repositories.EmployeeDaoInterface;

@Service
public class EmployeeDaoImpl implements EmployeeDaoInterface {
	
	@Autowired
	private JdbcTemplate jdbcTemplate;

	@Override
	public void save(Employee employee) {
		// TODO Auto-generated method stub
		
		
		String query="insert into emp_details values ('"+employee.getName()+"','"+employee.getId()+"')";
		
	jdbcTemplate.execute(query);
		
		
		
		
		
	}

	@Override
	public Employee findEmployee(int id) {
		// TODO Auto-generated method stub
		String query="select * from emp_details where id=?";
	return	jdbcTemplate.queryForObject(query,new Object[]{id}, (rs,res) -> new Employee(rs.getString("name"),rs.getInt("id")));
		
	}

}
