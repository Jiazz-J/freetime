package com.mine.simplejdbcannotation.repositories;

import org.springframework.stereotype.Repository;

import com.mine.simplejdbcannotation.models.Employee;

@Repository
public interface EmployeeDaoInterface {
	
	void save(Employee employee);
	Employee findEmployee(int id);
	
	
	

}
