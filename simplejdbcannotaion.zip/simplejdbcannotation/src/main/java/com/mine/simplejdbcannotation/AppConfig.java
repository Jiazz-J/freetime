package com.mine.simplejdbcannotation;


import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;
import org.springframework.core.env.Environment;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.datasource.DriverManagerDataSource;

@Configuration
@ComponentScan(basePackages="com.mine")
@PropertySource("classpath:db.properties")
public class AppConfig {
	
	
	
	@Autowired
	private Environment environment;
	
	@Bean
	public DataSource dataSource() {
		
		DriverManagerDataSource dMSource=new DriverManagerDataSource();
		dMSource.setDriverClassName("com.mysql.jdbc.Driver");
		dMSource.setUrl("jdbc:mysql://localhost:3306/benchtime");
		dMSource.setUsername("db_me");
		dMSource.setPassword("admin");
		
		//look username is not related to the property file.. It is giving current user on windows
		
		System.out.println(environment.getProperty("driver"));
		System.out.println(environment.getProperty("url"));
		System.out.println(environment.getProperty("username"));
		System.out.println(environment.getProperty("password"));
		
		return dMSource;
		
		
	}
	
	@Bean
	public JdbcTemplate jdbcTemplate(DataSource dataSource) {
		
		JdbcTemplate jdbcTemplate_=new JdbcTemplate();
		jdbcTemplate_.setDataSource(dataSource);
		return jdbcTemplate_;
	}

}
