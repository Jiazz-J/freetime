package com.mine.simplehibernatesession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import com.mine.simplehibernatesession.models.Employee;
import com.mine.simplehibernatesession.services.EmployeeService;

/**
 * Hello world!
 *
 */
public class App 
{
	@Autowired
	private static EmployeeService employeeService;
	
	
    public static void main( String[] args )
    {
        System.out.println( "Hello World!" );
        ApplicationContext context=new AnnotationConfigApplicationContext(JpaConfig.class);
        
        Employee employee =new Employee();
        employee.setId(102);
        employee.setName("kish");
        
        
    }
    
   
   
}
