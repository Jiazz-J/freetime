package com.mine.simplehibernatesession.services;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.mine.simplehibernatesession.models.Employee;
import com.mine.simplehibernatesession.repositories.EmployeeRepo;

@Service
public class EmployeeService {
	
	@Autowired
	private EmployeeRepo employeeRepo;

	
	public void save(Employee employee) {
		
		employeeRepo.save(employee);
	}
	
	public Employee getEmployee(int id) {
		return employeeRepo.findById(id).orElse(null);
	}
}
