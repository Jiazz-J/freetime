package com.mine.simplexml;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.mine.simplexml.models.Employee;

/**
 * Hello world!
 *
 */
public class App 
{
    public static void main( String[] args )
    {
        System.out.println( "Hello World!" );
        ApplicationContext context=new ClassPathXmlApplicationContext("spring-config.xml");
        Employee employee =(Employee)context.getBean(Employee.class);
        System.out.println(employee.getId()+"  "+employee.getName());
    }
}
