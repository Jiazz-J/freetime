package com.mine.simplejdbcxml;

import java.sql.SQLException;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.mine.simplejdbcxml.models.Employee;
import com.mine.simplejdbcxml.services.EmployeeServiceImpl;

/**
 * Hello world!
 *
 */
public class App 
{
    public static void main( String[] args ) throws SQLException
    {
        System.out.println( "Hello World!" );
        
        ApplicationContext  context=new ClassPathXmlApplicationContext("spring-config.xml");
        EmployeeServiceImpl employeeServiceImpl=context.getBean(EmployeeServiceImpl.class);
        Employee employee=context.getBean(Employee.class);
        employee.setId(123);
        employee.setName("mine");
        employeeServiceImpl.saveEmployee(employee);
        
        
    }
}
