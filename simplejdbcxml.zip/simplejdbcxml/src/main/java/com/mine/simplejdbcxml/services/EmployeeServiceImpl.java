package com.mine.simplejdbcxml.services;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.List;

import javax.sql.DataSource;

import com.mine.simplejdbcxml.models.Employee;
import com.mine.simplejdbcxml.respositories.EmployeeInterface;
import com.mysql.cj.protocol.Resultset;

public class EmployeeServiceImpl implements EmployeeInterface{
	
	
	private DataSource dataSource;
	private Connection con=null;
	
	
	public void setDataSource(DataSource dataSource) {
		this.dataSource=dataSource;
		
	}

	@Override
	public int saveEmployee(Employee employee) throws SQLException {
		// TODO Auto-generated method stub
		con=dataSource.getConnection();
		String query="insert into emp_details values(?,?)";
		Statement statement=con.createStatement();
		PreparedStatement preparedStatement=con.prepareStatement(query);
		preparedStatement.setInt(1, employee.getId());
		preparedStatement.setString(2, employee.getName());
		preparedStatement.execute();
		
	//	con.commit();
		
		
		
		return 0;
	}

	@Override
	public List<Employee> getEmployees() throws SQLException {
		// TODO Auto-generated method stub
		String query="Select * from emp_details";
		Statement statement=con.createStatement();
		//PreparedStatement preparedStatement=con.prepareStatement(query);
		
		List<Employee> empList=null;
		ResultSet resultset = statement.executeQuery(query);
		while(resultset.next()) {
			Employee employee =new Employee();
			employee.setId(resultset.getInt(1));
			employee.setName(resultset.getString(2));
			empList.add(employee);
		}
		
		return empList;
	}

	@Override
	public Employee getEmployee(int id) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public boolean deleteEmployee(int id) {
		// TODO Auto-generated method stub
		return false;
	}

}
