package com.mine.simplejdbcxml.respositories;

import java.sql.SQLException;
import java.util.List;

import com.mine.simplejdbcxml.models.Employee;

public interface EmployeeInterface {
	
	int saveEmployee(Employee employee) throws SQLException;
	
	List<Employee> getEmployees() throws SQLException;
	Employee getEmployee(int id) throws SQLException;
	boolean deleteEmployee(int id) throws SQLException;

}
