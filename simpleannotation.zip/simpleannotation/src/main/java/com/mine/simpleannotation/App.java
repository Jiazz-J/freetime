package com.mine.simpleannotation;

import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Import;

import com.mine.simpleannotation.models.Employee;

/**
 * Hello world!
 *
 */
@Configuration
@ComponentScan(basePackages = "com.mine")
public class App 
{
    public static void main( String[] args )
    {
        System.out.println( "Hello World!" );
        ApplicationContext context=new AnnotationConfigApplicationContext(App.class);
        Employee employee=context.getBean(Employee.class);
        employee.setId(123);
        employee.setName("meem");
        System.out.println(employee.getId()+"  "+employee.getName());
    }
}
