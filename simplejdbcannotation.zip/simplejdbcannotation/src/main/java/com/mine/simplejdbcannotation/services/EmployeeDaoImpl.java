package com.mine.simplejdbcannotation.services;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Service;

import com.mine.simplejdbcannotation.models.Employee;
import com.mine.simplejdbcannotation.repositories.EmployeeDaoInterface;

@Service
public class EmployeeDaoImpl implements EmployeeDaoInterface {
	
	@Autowired
	private JdbcTemplate jdbcTemplate;

	
	
	@Override
	public void save(Employee employee) {
		// TODO Auto-generated method stub
		String query="insert into emp_desc values('"+employee.getMobile()+"','"+employee.getCity()+"')";
		jdbcTemplate.update(query);
		
	}

	@Override
	public Employee findById(int id) {
		// TODO Auto-generated method stub
		String query = "select * from emp_desc where mobile='"+id+"'";
	return	jdbcTemplate.queryForObject(query, (rs,rowNum) -> new Employee(rs.getInt("mobile"),rs.getString("city")));
		
		
		
	}

}
