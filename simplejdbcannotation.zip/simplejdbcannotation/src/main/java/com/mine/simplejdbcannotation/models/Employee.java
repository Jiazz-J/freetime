package com.mine.simplejdbcannotation.models;

public class Employee {
	private int mobile;
	private String city;
	
	public Employee(int mobile,String city) {
		// TODO Auto-generated constructor stub
		this.mobile=mobile;
		this.city=city;
	}
	public int getMobile() {
		return mobile;
	}
	public void setMobile(int mobile) {
		this.mobile = mobile;
	}
	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}
	

}
