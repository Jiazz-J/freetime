package com.mine.simplejdbcannotation;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import com.mine.simplejdbcannotation.models.Employee;
import com.mine.simplejdbcannotation.repositories.EmployeeDaoInterface;
import com.mine.simplejdbcannotation.services.EmployeeDaoImpl;

/**
 * Hello world!
 *
 */
public class App 
{
    public static void main( String[] args )
    {
        System.out.println( "Hello World!" );
        
        ApplicationContext context=new AnnotationConfigApplicationContext(AppConfig.class);
        
        EmployeeDaoImpl dao=context.getBean(EmployeeDaoImpl.class);
       // dao.save(new Employee(99124, "chennai"));
       Employee employee= dao.findById(99124);
        System.out.println(employee.getCity()+" "+employee.getMobile());
        
    }
}
